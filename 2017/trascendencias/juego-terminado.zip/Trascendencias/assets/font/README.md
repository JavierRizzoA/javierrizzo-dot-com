Font files, ttf format, should be placed in this folder. They can be organized in sub-folders if necessary.
